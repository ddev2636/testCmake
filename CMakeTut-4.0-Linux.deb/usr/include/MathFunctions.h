// MathFunctions.h
#ifndef MATHFUNCTIONS_H
#define MATHFUNCTIONS_H

// Function to calculate the square root of a number
double squareRoot(double value);

#endif // MATHFUNCTIONS_H
